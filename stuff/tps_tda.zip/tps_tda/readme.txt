# TDA hands-on session with python and gudhi
# Francesco Costantino and Jules Vidal

# Installation guidelines for the Topological Data Analysis (TDA) hands-on session

## General requirements

  This hands-on session requires a working version of python 3 with the following modules installed:
    - numpy
    - matplotlib
    - notebook
    - gudhi 
    - kmapper
    - scikit-learn 
    - networkx 
    - ipympl 
    - seaborn 
    - pandas

You can install these modules using pip if you have access to a terminal with
a UNIX shell and a working version of python, with the following steps:

## Installation steps using pip on UNIX or Windows Subsystem for Linux:

  A working version of Python 3 is required, with the package installer pip.
  If it is not available, please refer to the python installation
  guidelines from https://www.python.org/

  
1) Install the required packages with pip:

    $ pip install numpy matplotlib notebook gudhi kmapper scikit-learn networkx ipympl seaborn pandas

3) Test the installation by trying to run the tda_working_example.ipynb notebook:

    $ jupyter notebook tda_working_example.ipynb

   If the cells of the notebook run without errors and the figures are reproduced, you are good to go !


